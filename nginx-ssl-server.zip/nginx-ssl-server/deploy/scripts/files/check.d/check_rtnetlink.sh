#!/bin/bash
SERVICE="mdns_add_alias.service"
EXCEPTION="RTNETLINK answers: Network is unreachable"

journalctl -u "$SERVICE" -n 50 | grep -qF "$EXCEPTION"
exit $?
