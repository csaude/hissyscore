#!/bin/bash
env_file="/etc/mdns_add_alias/mdns_add_alias.env"

if [[ ! -f "$env_file" ]]; then
  echo "[ERROR] Config file not found: $env_file"
  exit 1
fi

source "$env_file"

failed_pings=0

for host in "${hosts[@]}"; do
  if ! ping -c 1 -W 2 "$host.local" &> /dev/null; then
    ((failed_pings++))
  fi
done
if [ $failed_pings -gt 0 ]; then
   exit 1
else
  exit 0
fi
