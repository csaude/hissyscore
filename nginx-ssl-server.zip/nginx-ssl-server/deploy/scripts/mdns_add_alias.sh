#!/bin/bash
env_file="/etc/.mdns_add_hosts.env"
while true
do
  if [ -f "$env_file" ]; then
    source "$env_file"
  else
    echo "File $env_file not found."
    exit 1
  fi
  current_published=$(ps -ef | grep avahi-publish | grep -v grep | awk '{print $NF}' | sed 's/.local//')
  for published_host in $current_published; do
    if [[ ! " ${hosts[@]} " =~ " ${published_host} " ]]; then
      echo "Stopping avahi-publish for $published_host.local"
      pkill -f "avahi-publish -a -R $published_host.local"
    fi
  done
  for host in "${hosts[@]}"; do
    if ! pgrep -f "avahi-publish -a -R $host.local" > /dev/null; then
      echo "Starting avahi-publish for $host.local"
      /usr/bin/avahi-publish -a -R "$host.local" "$(ip route get 1.1.1.1 | awk '{print $7}')" &
    fi
  done
sleep 10
done
