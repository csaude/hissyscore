#!/bin/bash
env_file="/etc/.mdns_add_hosts.env"
while true
do
  if [ -f "$env_file" ]; then
    source "$env_file"
    current_published=$(ps -ef | grep avahi-publish | grep -v grep | awk '{print $NF}' | sed 's/.local//')
    for published_host in $current_published; do
      if [[ ! " ${hosts[@]} " =~ " ${published_host} " ]]; then
        pkill -f "avahi-publish -a -R $published_host.local"
      fi
    done
    for host in "${hosts[@]}"; do
      if ! pgrep -f "avahi-publish -a -R $host.local" > /dev/null; then
        /usr/bin/avahi-publish -a -R "$host.local" "$(ip route get 1.1.1.1 | awk '{print $7}')" &
      fi
    done
  fi
sleep 10
done
