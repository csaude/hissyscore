#!/bin/bash
set -e
LOCKFILE="/var/run/mdns_add_alias.lock"
ENV_FILE="/etc/mdns_add_alias/mdns_add_alias.env"
CHECK_DIR="/etc/mdns_add_alias/check.d"
RECHECK_INTERVAL=10

# Prevent multiple instances
exec 9>"$LOCKFILE"
if ! flock -n 9; then
  echo "[ERROR] Another instance is already running."
  exit 1
fi

echo "[INFO] mdns_add_alias started."

while true; do
  # --- Run all health checks ---
  for check in "$CHECK_DIR"/*; do
    if [ -x "$check" ]; then
      "$check"
      status=$?
      if [ $status -ne 0 ]; then
        echo "[ERROR] Check '$check' failed with code $status. Restarting service..."
        systemctl restart mdns_add_alias.service
        exit 0
      fi
    fi
  done

  # --- Source aliases ---
  if [ -f "$ENV_FILE" ]; then
    source "$ENV_FILE"
    current_published=$(ps -ef | grep '[a]vahi-publish' | awk '{print $NF}' | sed 's/.local//')

    for published in $current_published; do
      if [[ ! " ${hosts[@]} " =~ " ${published} " ]]; then
        echo "[INFO] Removing stale alias: $published"
        pkill -f "avahi-publish -a -R $published.local"
      fi
    done

    for host in "${hosts[@]}"; do
      if ! pgrep -f "avahi-publish -a -R $host.local" > /dev/null; then
        ip_addr=$(ip route get 1.1.1.1 | awk '{print $7}')
        echo "[INFO] Publishing alias: $host.local -> $ip_addr"
        /usr/bin/avahi-publish -a -R "$host.local" "$ip_addr" &
      fi
    done
  fi

  sleep "$RECHECK_INTERVAL"
done
