#!/bin/bash
if [ `dpkg -l |grep -E 'avahi-daemon|avahi-utils' |wc -l` -lt 2 ]
then
  echo "Please install avahi-daemon and avahi-utils. Using the bellow command."
  echo
  echo "apt-get install avahi-daemon avahi-utils"
  echo
  exit
fi
add_alias_script="`pwd`/scripts/mdns_add_alias.sh"
echo
cp ./scripts/files/mdns_add_alias.service /etc/systemd/system/
sed -i 's/EXECSTART/'$add_alias_script'/g'
systemctl daemon-reload
systemctl enable mdns_add_alias.service
echo Starting add aliases
systemctl start mdns_add_alias.service
for i in sesp idmed hl7 muzima sclinico epts
do
  delay_before_test=5
  echo -n "Going to ping new hosts... "
  while [ "$delay_before_test" -gt 0 ]
  do
    echo -n $delay_before_test " "
    delay_before_test=$((delay_before_test - 1))
    sleep 1
  done
  echo
  echo -n "Pinging $i.local ......"
  ping -c 2 $i.local 2&1>/dev/null
  if [ "$?" == "0" ]
  then
    echo "OK."
  else
    echo "FAILED!"
  fi
done
