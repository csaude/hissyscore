#!/bin/bash
# Just to make sure avahi has started
sleep 10
while true
do
  for i in sesp idmed hl7 muzima sclinico epts
  do
    if [ `ps -ef |grep publish |grep $i |grep -v grep |wc -l` -eq 0 ]
    then
      /usr/bin/avahi-publish -a -R $i.local $(ip route get 1.1.1.1 | awk '{print $7}') &
    fi
  done
  sleep 10
done

