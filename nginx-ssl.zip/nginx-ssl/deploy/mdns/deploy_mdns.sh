#!/bin/bash
if [ `dpkg -l |grep -E 'avahi-daemon|avahi-utils' |wc -l` -lt 2 ]
then
  echo "Please install avahi-daemon and avahi-utils. Using the bellow command."
  echo
  echo "apt-get install avahi-daemon avahi-utils"
  echo
  exit
fi
cronfile="/var/spool/cron/crontabs/root"
mv /etc/avahi/avahi-daemon.conf /etc/avahi/avahi-daemon.conf_`date +'%Y%m%d%H%m%S'`
cp ./scripts/files/avahi-daemon.conf /etc/avahi
systemctl restart avahi-daemon.service
add_names="`pwd`/scripts/avahi_add_names.sh"
if [ `cat $cronfile |grep avahi_add_names.sh |wc -l` -eq 0 ]
then
  echo "@reboot $add_names" >$cronfile
fi
echo "Process conpleted sucessfully!"
echo
echo Starting add aliases
$add_names &
for i in sesp idmed hl7 muzima sclinico epts
do
  echo -n "Pinging $i.local ......"
  ping -c 2 $i.local 2>/dev/null
  if [ "$?" == "0" ]
  then
    echo "OK."
  else
    echo "FAILED!"
  fi
done
