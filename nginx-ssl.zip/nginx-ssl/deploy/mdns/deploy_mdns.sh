#!/bin/bash
hosts=(sesp idmed hl7 muzima sclinico epts)
if [ "$1" != "--test" ]
then
  if [ `dpkg -l |grep -E 'avahi-daemon|avahi-utils' |wc -l` -lt 2 ]
  then
    echo "Please install avahi-daemon and avahi-utils. Using the bellow command."
    echo
    echo "apt-get install avahi-daemon avahi-utils"
    echo
    exit
  fi
  echo
  echo "Installing mdns_add_alias.service"
  cp ./scripts/files/mdns_add_alias.service /etc/systemd/system/
  cp ./scripts/mdns_add_alias.sh /etc/
  echo "Reloading Systemd daemon"
  systemctl daemon-reload
  echo "Enabling mdns_add_alias.service"
  systemctl enable mdns_add_alias.service
  echo "Starting mdns_add_alias.service"
  systemctl start mdns_add_alias.service
fi
delay_before_test=10
echo
echo -n "Going to ping new hosts... "
if [ "$1" != "--test" ]
then
  while [ "$delay_before_test" -gt 0 ]
  do
    echo -n $delay_before_test" "
    delay_before_test=$((delay_before_test - 1))
    sleep 1
  done
fi
echo
for host in "${hosts[@]}"; do
  echo -n "  Pinging $host.local ......"
  if ping -c 1 "$host" &> /dev/null; then
      echo "$host: OK."
  else
      echo "$host: FAILED!"
  fi
done
echo
echo "Use $0 --test to repeat ping test only."
