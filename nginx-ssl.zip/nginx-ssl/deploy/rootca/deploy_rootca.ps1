# PowerShell script to import a certificate into the Trusted Root Certification Authorities

$certPath = "$PSScriptRoot\scripts\files\issuing-policy-ca-chain.cert.pem"

# Ensure the certificate file exists
if (-Not (Test-Path -Path $certPath)) {
    Write-Host "Certificate file not found: $certPath"
    exit 1
}

# Import the certificate into the Trusted Root Certification Authorities store
$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
$cert.Import($certPath)

$store = New-Object System.Security.Cryptography.X509Certificates.X509Store "Root", "LocalMachine"
$store.Open("ReadWrite")
$store.Add($cert)
$store.Close()

Write-Host "Certificate imported successfully into Trusted Root Certification Authorities store."

# Refresh Firefox NSS database (if Firefox is installed)
$firefoxProfiles = Get-ChildItem "$env:APPDATA\Mozilla\Firefox\Profiles\*.default" -Directory
foreach ($profile in $firefoxProfiles) {
    $certutilPath = "C:\Program Files\Mozilla Firefox\certutil.exe"
    if (Test-Path -Path $certutilPath) {
        & $certutilPath -A -n "C-Saude Root CA" -t "TCu,Cu,Tu" -i "$certPath" -d "sql:$profile"
        Write-Host "Certificate added to Firefox profile: $profile"
    }
}

Write-Host "Process completed!"
