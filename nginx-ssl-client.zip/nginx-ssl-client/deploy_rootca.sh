#!/bin/bash
### Script installs root.cert.pem to certificate trust store of applications using NSS
### (e.g. Firefox, Thunderbird, Chromium)
### Mozilla uses cert8, Chromium and Chrome use cert9
###
### Requirement: apt install libnss3-tools
###
if [ `id -u` -ne 0 ]
  then echo Please run this script as root or using sudo!
  exit
fi
sudo apt-get install avahi-daemon avahi-utils libnss3-tools -y

certfile="`pwd`/files/issuing-policy-ca-chain.cert.pem"
certname="C-Saude Root CA"

echo "Locating certDB for all users in /home ....."
for certDB in $(find /home -name "cert[89].db")
do
  certdir=$(dirname "${certDB}")
  if [ -f "${certdir}/cert8.db" ]; then
    type="dbm"
  elif [ -f "${certdir}/cert9.db" ]; then
    type="sql"
  else
    echo "No valid cert8.db or cert9.db found in ${certdir}"
    continue
  fi
  echo "Adding ROOT CA to $certDB"
  certutil -A -n "${certname}" -t "TCu,Cu,Tu" -i "${certfile}" -d "${type}:${certdir}"
done
echo "Process completed!"
echo
